const questions = [
    {
        question: "What does 'HTML' stand for?",
        options: ["Hyper Transfer Markup Language", "Hyper Text Markup Language", "Hyperlink and Text Markup Language", "High Technical Markup Language"],
        correctAnswer: "B"
    },
    {
        question: "Which of the following is an example of a high-level programming language?",
        options: ["C++", "Binary", "Assembly", "Machine code"],
        correctAnswer: "A"
    },
    {
        question: "What does 'CPU' stand for?",
        options: ["Central Processing Unit", "Computer Processing Unit", "Central Process Unit", "Core Processing Unit"],
        correctAnswer: "A"
    },
    {
        question: "What is the purpose of RAM (Random Access Memory) in a computer?",
        options: ["Long-term storage of data", "Running the operating system", "Temporary storage of data and programs", "Displaying graphics"],
        correctAnswer: "C"
    },
    {
        question: "Which data structure follows the 'First In, First Out' (FIFO) principle?",
        options: ["Stack", "Queue", "Array", "Linked List"],
        correctAnswer: "B"
    }
];




let currentQuestionIndex = 0;
let score = 0;
let timer; // Variable to hold the timer interval
let timeLeft = 0; // Variable to store remaining time
const timerDuration = 60; // Fixed duration for each question in seconds

const questionText = document.getElementById("question-text");
const optionsContainer = document.querySelector(".options");
const nextButton = document.getElementById("next-button");
const restartButton = document.getElementById("restart-button");
const resultText = document.getElementById("result");
const timerText = document.getElementById("timer");

function loadQuestion() {
    clearInterval(timer); // Clear the previous timer (if any)

    if (currentQuestionIndex >= 0 && currentQuestionIndex < questions.length) {
        const currentQuestion = questions[currentQuestionIndex];
        questionText.textContent = `Question ${currentQuestionIndex + 1}: ${currentQuestion.question}`;

        optionsContainer.innerHTML = "";

        currentQuestion.options.forEach((option, index) => {
            const radioInput = document.createElement("input");
            radioInput.type = "radio";
            radioInput.name = "answer";
            radioInput.value = String.fromCharCode(65 + index); // A, B, C, D
            const label = document.createElement("label");
            label.appendChild(radioInput);
            label.appendChild(document.createTextNode(` ${option}`));
            optionsContainer.appendChild(label);
        });

        startTimer();
    } else {
        showResult();
    }

    updateButtonsVisibility();
}

function startTimer(initialTime = timerDuration) {
    clearInterval(timer); // Clear any existing timer

    timerText.style.display = "block"; // Show the timer
    timeLeft = initialTime;
    timerText.textContent = `Time left: ${timeLeft} seconds`;

    timer = setInterval(function () {
        timeLeft--;
        timerText.textContent = `Time left: ${timeLeft} seconds`;

        if (timeLeft === 0) {
            clearInterval(timer);
            checkAnswer(); // Automatically move to the next question
        }
    }, 1000);
}

function checkAnswer() {
    const selectedOption = document.querySelector("input[name='answer']:checked");

    if (selectedOption) {
        const userAnswer = selectedOption.value;
        const correctAnswer = questions[currentQuestionIndex].correctAnswer;

        if (userAnswer === correctAnswer) {
            score++;
        }

        currentQuestionIndex++;

        loadQuestion();
    } else {
        // If no answer is selected, move to the next question directly
        currentQuestionIndex++;
        loadQuestion();
    }
}

function showResult() {
    questionText.textContent = "";
    optionsContainer.innerHTML = "";
    nextButton.style.display = "none";
    restartButton.style.display = "block";
    resultText.textContent = `Your Score: ${score} out of ${questions.length}`;

    timerText.style.display = "none";
}

function restartQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    resultText.textContent = "";
    nextButton.style.display = "block";
    restartButton.style.display = "none";
    loadQuestion();
    startTimer(); // Start the timer with the default time of 60 seconds
    timerText.style.display = "block"; // Show the timer when restarting
}

function updateButtonsVisibility() {
    if (currentQuestionIndex === questions.length - 1) {
        nextButton.textContent = "Finish"; // Change button text to "Finish" on the last question
    } else if (currentQuestionIndex === questions.length) {
        nextButton.style.display = "none"; // Hide the next button at the end of the quiz
    } else {
        nextButton.textContent = "Next"; // Reset button text to "Next" on other questions
    }
}

loadQuestion();

nextButton.addEventListener("click", function() {
    if (currentQuestionIndex === questions.length) {
        // If on the last page, go to result page or take any other desired action
        // For example, you can redirect to a different page or show a summary.
        // You can customize this part according to your requirements.
    } else {
        checkAnswer();
    }
});
restartButton.addEventListener("click", restartQuiz);

